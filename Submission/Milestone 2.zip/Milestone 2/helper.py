import numpy as np
import tensorflow as tf

from Metrics.NMSE import NMSE
from Modules.GaussianDictionaryFilter import GaussianDictionaryFilter as DictionaryFilter
from Modules.NMF import NMF
from Modules.MVGMF import MVGMF


def create_dataset(num_movies, num_users, train_sparse_tensor, test_sparse_tensor):
    """
    Create a TF dataset from the sparse tensors.
    """
    def data_generator():
        train_slices = tf.sparse.split(sp_input=train_sparse_tensor, num_split=num_users, axis=1)
        test_slices = tf.sparse.split(sp_input=test_sparse_tensor, num_split=num_users, axis=1)
        for i in range(num_users):
            yield (tf.sparse.to_dense(train_slices[i]), tf.sparse.to_dense(test_slices[i]))

    dataset = tf.data.Dataset.from_generator(
        data_generator, 
        output_signature=(
            tf.TensorSpec(shape=[num_movies, None], dtype=tf.float32),
            tf.TensorSpec(shape=[num_movies, None], dtype=tf.float32)
        )
    )

    return dataset


def fit_nmf(num_movies, num_users, num_factors, init_scale, num_epochs, train_sparse_tensor, test_sparse_tensor):
    """
    Fits a NMF model to the data and returns the training and testing NMSEs.
    """

    # Initialize variables
    nmf_train_nmse = []
    nmf_test_nmse = []

    # Create the model
    nmf = NMF(m = num_movies, n = num_users, num_factors=num_factors, init_scale=init_scale)
    train_nmse = NMSE()
    test_nmse = NMSE()

    # Create the dense matrices
    train_tensor = tf.cast(tf.sparse.to_dense(train_sparse_tensor), tf.float32)
    train_mask = tf.cast(tf.not_equal(train_tensor, 0), tf.float32)
    test_tensor = tf.cast(tf.sparse.to_dense(test_sparse_tensor), tf.float32)
    test_mask = tf.cast(tf.not_equal(test_tensor, 0), tf.float32)

    # Train the model
    for epoch in range(num_epochs):
        nmf(train_tensor, train_mask)
        pred = tf.matmul(nmf.C, nmf.X)

        train_nmse.update_state(train_tensor, pred, train_mask)
        test_nmse.update_state(test_tensor, pred, test_mask)

        nmf_train_nmse.append(train_nmse.result().numpy())
        nmf_test_nmse.append(test_nmse.result().numpy())
    
    return nmf_train_nmse, nmf_test_nmse


def fit_mvgmf(num_movies, num_users, num_factors, k, sigma, init_scale, num_epochs, train_sparse_tensor, test_sparse_tensor):
    """
    Fits a MVGMF model to the data and returns the training and testing NMSEs.
    """

    # Initialize variables
    mvgmf_train_nmse = []
    mvgmf_test_nmse = []

    # Create the model
    mvgmf = MVGMF(m = num_movies, n = num_users, num_factors=4, k=k, sigma=sigma, init_scale=init_scale)
    train_nmse = NMSE()
    test_nmse = NMSE()

    # Create the dense matrices
    train_tensor = tf.cast(tf.sparse.to_dense(train_sparse_tensor), tf.float32)
    train_mask = tf.cast(tf.not_equal(train_tensor, 0), tf.float32)
    test_tensor = tf.cast(tf.sparse.to_dense(test_sparse_tensor), tf.float32)
    test_mask = tf.cast(tf.not_equal(test_tensor, 0), tf.float32)

    # Train the model
    for epoch in range(num_epochs):
        mvgmf(train_tensor, train_mask)
        pred = tf.matmul(mvgmf.C, mvgmf.X)

        train_nmse.update_state(train_tensor, pred, train_mask)
        test_nmse.update_state(test_tensor, pred, test_mask)

        mvgmf_train_nmse.append(train_nmse.result().numpy())
        mvgmf_test_nmse.append(test_nmse.result().numpy())

    return mvgmf_train_nmse, mvgmf_test_nmse


def fit_df(num_movies, num_users, num_factors, init_scale, train_lambda, num_epochs, train_sparse_tensor, test_sparse_tensor):
    """
    Fits a Dictionary Filter model to the data and returns the training and testing NMSEs.
    """

    # Initialize variables
    df_train_nmse = np.zeros(num_epochs)
    df_test_nmse = np.zeros(num_epochs)

    # Create the model
    model = DictionaryFilter(num_movies, num_factors, init_scale, train_lambda)
    train_nmse = NMSE()
    test_nmse = NMSE()

    # Create the dataset
    dataset = create_dataset(num_movies=num_movies, num_users=num_users, train_sparse_tensor=train_sparse_tensor, test_sparse_tensor=test_sparse_tensor)

    # Train the model
    for epoch in range(num_epochs):
        for train_batch, test_batch in dataset:
            x = model(train_batch)
            train_nmse.update_state(train_batch, tf.matmul(model.C, x), tf.cast(tf.not_equal(train_batch, 0.0), tf.float32))
            test_nmse.update_state(test_batch, tf.matmul(model.C, x), tf.cast(tf.not_equal(test_batch, 0.0), tf.float32))

        df_train_nmse[epoch] = train_nmse.result().numpy()
        df_test_nmse[epoch] = test_nmse.result().numpy()

    return df_train_nmse, df_test_nmse